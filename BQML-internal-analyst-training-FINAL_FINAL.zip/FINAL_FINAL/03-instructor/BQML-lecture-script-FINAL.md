# BQML 내부 분석가 강의 — Lecture Script v1 draft

본 강의는 `slides-final.md`와 `facilitator-guide.md`를 기준으로 운영한다.

## 진행 핵심

1. BQML은 ML 이론이 아니라 SQL 기반 예측 분석 워크플로우라고 소개한다.
2. 첫 예시는 게임 데이터 회귀 예측이다.
   - `CREATE MODEL`
   - `ML.EVALUATE`
   - `ML.PREDICT`
   - actual vs predicted 비교
3. `rank_value`는 참고 컬럼이지만 모델 feature에서는 제외한다.
   - 이유: target leakage 가능성
4. 회귀 평가 지표에서 R²는 “모델이 실제값의 변동을 얼마나 설명했는가”로 설명한다.
   - 수식: R² = 1 - (SSE / SST)
   - 쉽게 말하면: 1 - (모델이 틀린 정도 / 원래 데이터가 들쭉날쭉한 정도)
   - 예: R²=0.72라면 실제값 변동의 약 72%를 모델이 설명한다는 뜻.
   - 단, R²가 높다고 무조건 좋은 모델은 아니며 과적합, target leakage, 샘플 편향, 실제 업무상 허용 오차를 함께 봐야 한다.
5. 두 번째 예시는 churn classification이다.
   - label sanity check
   - `LOGISTIC_REG`
   - evaluation
   - segment action priority
6. 마무리는 “예측값 → 액션 우선순위 → 실험/검증”으로 연결한다.

상세 진행 멘트와 시간 운영은 `facilitator-guide.md`를 따른다.
