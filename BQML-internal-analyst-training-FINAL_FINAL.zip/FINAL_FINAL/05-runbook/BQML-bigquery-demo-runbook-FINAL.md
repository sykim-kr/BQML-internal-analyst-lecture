# BQML 내부 분석가 강의 — BigQuery Demo Runbook

- Version: v1 draft
- Target project: `bigquery-course-356601`
- Dataset: `bqml_course_internal_analyst`
- Security level: L2 for additional writes
- Current status: churn classification demo environment created and verified; game regression query pack prepared, not yet executed by Chrong

## 0. 보안 메모

본 실습 환경은 synthetic/sample 데이터와 가명/샘플 ID 기준으로 구성되었으며, 실제 고객/개인 데이터 및 credential은 포함하지 않는다.

게임 데이터 예제의 CSV/DOCX/이미지는 교육용 source material로만 취급하며, 교재/쿼리에는 sample schema와 구조만 반영한다.

추가 BigQuery write가 필요한 경우 반드시 아래 순서를 따른다.

1. 기존 동일 이름 리소스 확인
2. dry run/비용 추정 확인
3. 확인 결과 실행 로그 기록
4. SY님 승인 문구 수령
5. BigQuery write 실행

## 1. Demo overview

강의 중 BigQuery demo는 두 단계로 운영한다.

### Demo 1 — Game revenue regression

목적:
- BQML 기본 문법을 가장 단순한 회귀 예제로 이해한다.

흐름:
```text
game sample table
→ CREATE MODEL LINEAR_REG
→ ML.EVALUATE
→ ML.PREDICT for user_id=156
→ actual vs predicted comparison
```

Query pack:
- `03-drafts/game-regression-query-pack-v0.sql`

생성 예정 리소스:
- `bqml_course_game_data`
- `bqml_course_game_data_profile`
- `bqml_course_game_revenue_model_v0`
- `bqml_course_game_model_evaluation`
- `bqml_course_game_user156_prediction`
- `bqml_course_game_all_predictions`

중요 모델링 메모:
- `rank_value`는 원본 `RANK` 컬럼이다.
- table/profile/result preview에는 포함한다.
- 하지만 `purchase_amount`에서 파생된 순위로 보이므로 모델 feature에서는 제외한다.
- 강의에서는 target leakage 방지 예시로 짧게 설명한다.

### Demo 2 — Churn classification / segment action priority

목적:
- 예측 결과를 개인 리스트가 아니라 세그먼트별 액션 우선순위로 해석한다.

흐름:
```text
synthetic users/events/orders
→ training_features
→ CREATE MODEL LOGISTIC_REG
→ ML.EVALUATE
→ ML.PREDICT
→ segment action priority
```

현재 생성 완료 리소스:
- `bqml_course_sample_users` — 500 rows
- `bqml_course_sample_events` — 10,000 rows
- `bqml_course_sample_orders` — 2,383 rows
- `bqml_course_training_features` — 500 rows
- `bqml_course_churn_model_v0`
- `bqml_course_model_evaluation` — 1 row
- `bqml_course_segment_action_priority` — 5 rows

현재 검증 결과:
- `churned=0`: 400 rows
- `churned=1`: 100 rows
- precision: 0.9
- recall: 0.9
- accuracy: 약 0.9588
- f1_score: 0.9
- roc_auc: 약 0.9660

Segment result:
- `dormant_risk`: avg_churn_probability 약 0.886, `high_priority_retention_message`
- 나머지 세그먼트: `monitor_only`

## 2. Demo 1 상세 진행 — Game regression

### Step 1. Game data table 확인

Console에서 확인:
```sql
SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_game_data`
LIMIT 20;
```

강의 설명:
- 게임시간, 로그인횟수, 달성레벨로 예상매출액을 예측한다.
- `rank_value`는 참고 컬럼이며 model feature에서는 제외한다.

### Step 2. Game data profile 확인

```sql
SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_game_data_profile`;
```

설명 포인트:
- 모델링 전 데이터 범위와 분포를 먼저 본다.
- 분석가는 모델보다 먼저 데이터 sanity check를 해야 한다.

### Step 3. Model 생성 쿼리 설명

핵심 SQL:
```sql
CREATE OR REPLACE MODEL `...bqml_course_game_revenue_model_v0`
OPTIONS(
  model_type = 'LINEAR_REG',
  input_label_cols = ['purchase_amount'],
  data_split_method = 'NO_SPLIT'
) AS
SELECT
  game_time,
  login_count,
  level_achieved,
  purchase_amount
FROM `...bqml_course_game_data`
WHERE user_id != 156;
```

설명 포인트:
- `model_type='LINEAR_REG'`: 숫자 값을 예측한다.
- `input_label_cols=['purchase_amount']`: 맞히고 싶은 값이다.
- `user_id=156`은 예측 비교용으로 학습에서 제외한다.

### Step 4. Evaluate 결과 확인

```sql
SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_game_model_evaluation`;
```

설명 포인트:
- MAE: 평균 절대 오차
- MSE: 큰 오차에 더 민감한 지표
- R2 / explained variance: 모델이 실제값의 변동을 얼마나 설명하는지. 수식은 `R² = 1 - (SSE / SST)`이며, 쉽게 말해 `1 - (모델이 틀린 정도 / 원래 데이터가 들쭉날쭉한 정도)`이다. 예: R²=0.72라면 실제값 변동의 약 72%를 모델이 설명한다는 뜻이다.
- 단, R²가 높다고 무조건 좋은 모델은 아니다. 과적합, target leakage, 샘플 편향, 업무상 허용 가능한 오차 범위를 함께 확인한다.
- 지표는 암기보다 “의사결정에 충분히 정확한가?”로 해석한다.

### Step 5. user_id=156 예측 결과 확인

```sql
SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_game_user156_prediction`;
```

설명 포인트:
- 실제값과 예측값을 나란히 비교한다.
- 예측값 자체보다 오차를 확인해야 한다.

## 3. Demo 2 상세 진행 — Churn classification

### Step 1. Training features 확인

```sql
SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
LIMIT 20;
```

### Step 2. Label sanity check

```sql
SELECT churned, COUNT(*) AS row_count
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
GROUP BY churned
ORDER BY churned;
```

기대 결과:
```text
churned=0 → 400
churned=1 → 100
```

설명 포인트:
- 분류 모델은 label에 최소 2개 class가 있어야 한다.
- 이 오류는 실제 분석에서도 자주 나는 데이터 준비 문제다.

### Step 3. Evaluate 결과 확인

```sql
SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_model_evaluation`;
```

설명 포인트:
- precision/recall은 액션 비용 관점으로 해석한다.
- 캠페인 비용이 낮으면 recall, 고비용 CS 개입이면 precision이 더 중요할 수 있다.

### Step 4. Segment action priority 확인

```sql
SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_segment_action_priority`
ORDER BY avg_churn_probability DESC;
```

설명 포인트:
- 개인 고객 리스트가 아니라 세그먼트별 우선순위다.
- `dormant_risk`는 retention message 우선 대상이다.

## 4. 강의 중 실패/복구 포인트

### 오류: label이 한 class만 있음

오류 메시지:
```text
Classification model requires at least 2 unique labels
```

설명:
- `LOGISTIC_REG`는 0/1 두 class가 모두 있어야 한다.
- synthetic label 또는 실제 label 정의를 점검해야 한다.

복구 원칙:
- PART A: feature/label table 재생성 + label sanity check
- PART B: 0/1 모두 확인 후 model/evaluation/prediction 실행

관련 파일:
- `03-drafts/bigquery-hotfix-part-a-training-features.sql`
- `03-drafts/bigquery-hotfix-part-b-model-results.sql`

## 5. Cleanup reference

Cleanup은 강의/검증 종료 후 SY님 별도 승인 시에만 수행한다.

Cleanup 대상 후보:
- game demo tables/model
- churn demo tables/model
- dataset 전체 삭제 여부는 별도 판단

주의:
- `DROP SCHEMA ... CASCADE`는 매우 강한 삭제 작업이므로 자동 실행하지 않는다.
