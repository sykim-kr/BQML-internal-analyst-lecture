# MANIFEST — FINAL_FINAL

## Canonical folder

`/Users/sykim/.openclaw/workspace/oceo/lectures/bqml-internal-analyst-202605/05-delivery/FINAL_FINAL/`

## Final presentation

- `01-ppt/BQML-internal-analyst-training-deck-FINAL.pptx`
  - Source: `05-delivery/bqml-internal-analyst-training-deck-v11-final-final.pptx`
  - Slides: 58
  - Includes: R² formula/explanation, End Of Document slide, final quote

## Learner worksheets

- `02-worksheets/BQML-worksheet-FINAL.md`
- `02-worksheets/BQML-worksheet-FINAL.html`
- `02-worksheets/BQML-worksheet-answer-guide-FINAL.md`
- `02-worksheets/BQML-worksheet-answer-guide-FINAL.html`

## Instructor materials

- `03-instructor/BQML-lecture-script-FINAL.md`
- `03-instructor/BQML-facilitator-guide-FINAL.md`
- `03-instructor/BQML-facilitator-guide-FINAL.html`

## BigQuery SQL

- `04-bigquery-sql/Game-regression-query-pack-FINAL.sql`
- `04-bigquery-sql/Game-regression-query-pack-notes-FINAL.md`
- `04-bigquery-sql/Churn-classification-create-evaluate-predict-FINAL.sql`
- `04-bigquery-sql/Churn-classification-full-setup-query-pack-REFERENCE.sql`
- `04-bigquery-sql/Churn-hotfix-part-a-training-features-REFERENCE.sql`
- `04-bigquery-sql/Churn-hotfix-part-b-model-results-REFERENCE.sql`

## Runbook

- `05-runbook/BQML-bigquery-demo-runbook-FINAL.md`

## QA reference

- `06-qa/ppt-editability-diagnosis-REFERENCE.md`
- `06-qa/ppt-editable-textbox-qa-REFERENCE.md`
- `06-qa/ppt-v7-feedback-revision-qa-REFERENCE.md`

## Package zip

- Parent folder zip: `../BQML-internal-analyst-training-FINAL_FINAL.zip`

## Decision

This folder is the single handoff location for final BQML internal analyst lecture materials.
