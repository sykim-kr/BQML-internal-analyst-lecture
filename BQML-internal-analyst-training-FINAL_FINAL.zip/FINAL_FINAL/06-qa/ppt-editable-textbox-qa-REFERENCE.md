# PPT v7 Fully Editable TextBox QA

Date: 2026-05-20

## Context

SY님 reported that the previous PPT v7 could open but text could not be edited reliably in PowerPoint. Layer reordering was insufficient, so the deck was rebuilt as a fresh PPTX structure.

## Artifact

- Source: `05-delivery/bqml-internal-analyst-training-deck-v7-feedback-revision.pptx`
- New editable PPTX: `05-delivery/bqml-internal-analyst-training-deck-v7-fully-editable-textboxes.pptx`
- Public copy: `../../../../public-slides/bqml-internal-analyst-lecture/bqml-internal-analyst-training-deck-v7-fully-editable-textboxes.pptx`
- Local download copy: `/Users/sykim/Downloads/bqml-internal-analyst-training-deck-v7-fully-editable-textboxes.pptx`

## QA Result

Generated as a fresh PPTX container with:

- Slides: 58
- Editable native text boxes: 319
- Editable native tables: 8
- AutoShapes containing text: 0

## Decision

Going forward, lecture PPTX deliverables must keep all learner-facing text as native PowerPoint TextBox/Table objects. Text embedded as images, locked layers, master-only text, or non-clickable object structures is not acceptable for delivery.
