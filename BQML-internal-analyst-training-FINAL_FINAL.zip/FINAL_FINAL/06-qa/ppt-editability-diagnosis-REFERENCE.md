# PPT v7 Plain Editable Placeholder QA

Date: 2026-05-20

## Context

SY님 reported that even the fresh TextBox/Table rebuild could not be edited in PowerPoint. To isolate whether the blocker is deck object structure or PowerPoint/download mode, created a design-sacrificed placeholder-only PPTX.

## Artifact

- Plain editable deck: `05-delivery/bqml-internal-analyst-training-deck-v7-plain-editable-placeholders.pptx`
- Public copy: `../../../../public-slides/bqml-internal-analyst-lecture/bqml-internal-analyst-training-deck-v7-plain-editable-placeholders.pptx`
- Local download copy: `/Users/sykim/Downloads/bqml-internal-analyst-training-deck-v7-plain-editable-placeholders.pptx`
- Canary: `/Users/sykim/Downloads/ppt-edit-canary-one-textbox.pptx`

## QA Result

Plain placeholder deck:

- Slides: 58
- Text shapes: 116
- PowerPoint placeholders: 116
- Tables: 0

Canary deck:

- Slides: 1
- Text shapes: 2
- PowerPoint placeholders: 1

## Interpretation

If the canary file is not editable either, the likely issue is PowerPoint opening mode, file provenance/protection, or app/account state rather than the BQML deck object structure.

If the canary is editable but the placeholder deck is not, rebuild again from a different production path (Keynote/PowerPoint automation or manual XML template) and preserve only minimal formatting.
