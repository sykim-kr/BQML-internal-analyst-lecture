-- BigQuery Hotfix PART A — training_features regeneration + label sanity check
-- Execute this first. Do NOT run PART B until this query returns both churned=0 and churned=1.
-- Target project: bigquery-course-356601
-- Security: L2, synthetic/sample data only, pseudo_user_key only.

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features` AS
WITH params AS (
  SELECT DATE '2026-04-01' AS as_of_date
), observed_events AS (
  SELECT
    e.pseudo_user_key,
    SUM(e.session_count) AS sessions_30d,
    COUNTIF(e.event_name = 'purchase') AS purchases_30d,
    DATE_DIFF((SELECT as_of_date FROM params), MAX(e.event_date), DAY) AS days_since_last_visit
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_events` e
  WHERE e.event_date BETWEEN DATE_SUB((SELECT as_of_date FROM params), INTERVAL 29 DAY)
                         AND (SELECT as_of_date FROM params)
  GROUP BY e.pseudo_user_key
), observed_orders AS (
  SELECT
    o.pseudo_user_key,
    SUM(o.order_amount) AS revenue_90d
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_orders` o
  WHERE o.order_date BETWEEN DATE_SUB((SELECT as_of_date FROM params), INTERVAL 89 DAY)
                         AND (SELECT as_of_date FROM params)
  GROUP BY o.pseudo_user_key
), future_activity AS (
  SELECT DISTINCT e.pseudo_user_key
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_events` e
  WHERE e.event_date BETWEEN DATE_ADD((SELECT as_of_date FROM params), INTERVAL 1 DAY)
                         AND DATE_ADD((SELECT as_of_date FROM params), INTERVAL 30 DAY)
)
SELECT
  u.pseudo_user_key,
  u.segment_key,
  COALESCE(oe.sessions_30d, 0) AS sessions_30d,
  COALESCE(oe.purchases_30d, 0) AS purchases_30d,
  COALESCE(oe.days_since_last_visit, 999) AS days_since_last_visit,
  COALESCE(oo.revenue_90d, 0.0) AS revenue_90d,
  -- Synthetic label guardrail: ensure both classes exist for BQML classification demo.
  -- This is education-only synthetic logic, not a real churn definition.
  CASE
    WHEN u.segment_key = 'dormant_risk' THEN 1
    WHEN COALESCE(oe.sessions_30d, 0) <= 2 AND COALESCE(oo.revenue_90d, 0.0) = 0 THEN 1
    WHEN fa.pseudo_user_key IS NULL AND MOD(CAST(REGEXP_EXTRACT(u.pseudo_user_key, r'u(\d+)') AS INT64), 3) = 0 THEN 1
    ELSE 0
  END AS churned
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_users` u
LEFT JOIN observed_events oe USING (pseudo_user_key)
LEFT JOIN observed_orders oo USING (pseudo_user_key)
LEFT JOIN future_activity fa USING (pseudo_user_key);

-- Sanity check: MUST return both churned=0 and churned=1 before PART B.
SELECT churned, COUNT(*) AS row_count
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
GROUP BY churned
ORDER BY churned;
