-- BQML Churn Classification — CREATE MODEL / EVALUATE / PREDICT reference SQL
-- Project: bigquery-course-356601
-- Dataset: bqml_course_internal_analyst
-- Purpose: Lecture reference only. Do not execute CREATE OR REPLACE blocks unless intentionally refreshing demo resources.
-- Data note: synthetic/sample data only; pseudo_user_key is a sample/generic ID.

-- ============================================================
-- 0. Label sanity check before CREATE MODEL
-- Expected: churned=0 -> 400, churned=1 -> 100
-- ============================================================

SELECT churned, COUNT(*) AS row_count
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
GROUP BY churned
ORDER BY churned;

-- ============================================================
-- 1. CREATE MODEL — Logistic regression churn classification
-- ============================================================

CREATE OR REPLACE MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
OPTIONS(
  model_type = 'LOGISTIC_REG',
  input_label_cols = ['churned'],
  auto_class_weights = TRUE,
  data_split_method = 'AUTO_SPLIT'
) AS
SELECT
  sessions_30d,
  purchases_30d,
  days_since_last_visit,
  revenue_90d,
  churned
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`;

-- ============================================================
-- 2. EVALUATE MODEL — direct evaluation query
-- ============================================================

SELECT *
FROM ML.EVALUATE(
  MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
);

-- Optional: persist evaluation output as a table for lecture display.
CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_model_evaluation` AS
SELECT *
FROM ML.EVALUATE(
  MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
);

-- ============================================================
-- 3. PREDICT MODEL — row-level prediction query
-- ============================================================

SELECT
  pseudo_user_key,
  segment_key,
  predicted_churned,
  predicted_churned_probs,
  sessions_30d,
  purchases_30d,
  days_since_last_visit,
  revenue_90d
FROM ML.PREDICT(
  MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`,
  (
    SELECT
      pseudo_user_key,
      segment_key,
      sessions_30d,
      purchases_30d,
      days_since_last_visit,
      revenue_90d
    FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
  )
);

-- ============================================================
-- 4. PREDICT → Segment action priority table
-- This is the lecture-friendly output: prediction result converted into action priority.
-- ============================================================

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_segment_action_priority` AS
WITH predictions AS (
  SELECT
    pseudo_user_key,
    segment_key,
    predicted_churned,
    predicted_churned_probs
  FROM ML.PREDICT(
    MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`,
    (
      SELECT
        pseudo_user_key,
        segment_key,
        sessions_30d,
        purchases_30d,
        days_since_last_visit,
        revenue_90d
      FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
    )
  )
), scored AS (
  SELECT
    pseudo_user_key,
    segment_key,
    predicted_churned,
    (
      SELECT prob
      FROM UNNEST(predicted_churned_probs)
      WHERE label = 1
      LIMIT 1
    ) AS churn_probability
  FROM predictions
)
SELECT
  segment_key,
  COUNT(*) AS pseudo_user_count,
  AVG(churn_probability) AS avg_churn_probability,
  CASE
    WHEN AVG(churn_probability) >= 0.70 THEN 'high_priority_retention_message'
    WHEN AVG(churn_probability) >= 0.50 THEN 'medium_priority_activation_nudge'
    ELSE 'monitor_only'
  END AS recommended_action
FROM scored
GROUP BY segment_key
ORDER BY avg_churn_probability DESC;

-- ============================================================
-- 5. Lecture display queries for already-created result tables
-- ============================================================

SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_model_evaluation`;

SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_segment_action_priority`
ORDER BY avg_churn_probability DESC;
