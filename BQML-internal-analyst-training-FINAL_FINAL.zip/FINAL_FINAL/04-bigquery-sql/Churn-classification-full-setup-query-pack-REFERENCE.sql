-- BigQuery Approval Query Pack v0
-- Project: lecture-bqml-internal-analyst-202605
-- Target project: bigquery-course-356601
-- Dataset: bqml_course_internal_analyst
-- Security: L2 write stage. Synthetic/sample data only. No direct identifiers.
-- Status: APPROVAL REQUIRED BEFORE EXECUTION
-- Notes:
--   - All resource names use bqml_course_* prefix.
--   - Data uses pseudo_user_key only.
--   - No email, phone, name, company_name, API key, token, or real customer identifiers.
--   - Optional appendix queries are commented out by default and require separate approval if executed.
--   - Before execution: check existing resources, dry run/cost estimate, execution log, and SY님 approval text.

-- ============================================================
-- 0. Dataset
-- ============================================================

CREATE SCHEMA IF NOT EXISTS `bigquery-course-356601.bqml_course_internal_analyst`
OPTIONS(
  location = 'US',
  description = 'Synthetic BQML demo dataset for internal analyst lecture'
);

-- ============================================================
-- 1. Synthetic source table: users
-- ============================================================

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_users` AS
SELECT
  FORMAT('u%04d', user_num) AS pseudo_user_key,
  DATE_SUB(DATE '2026-05-01', INTERVAL MOD(user_num, 180) DAY) AS signup_date,
  CASE
    WHEN MOD(user_num, 5) = 0 THEN 'high_value'
    WHEN MOD(user_num, 5) = 1 THEN 'new_explorer'
    WHEN MOD(user_num, 5) = 2 THEN 'dormant_risk'
    WHEN MOD(user_num, 5) = 3 THEN 'price_sensitive'
    ELSE 'active_buyer'
  END AS segment_key,
  CASE
    WHEN MOD(user_num, 4) = 0 THEN 'organic'
    WHEN MOD(user_num, 4) = 1 THEN 'paid_search'
    WHEN MOD(user_num, 4) = 2 THEN 'paid_social'
    ELSE 'referral'
  END AS acquisition_channel
FROM UNNEST(GENERATE_ARRAY(1, 500)) AS user_num;

-- ============================================================
-- 2. Synthetic source table: events
-- ============================================================

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_events` AS
WITH users AS (
  SELECT
    pseudo_user_key,
    CAST(REGEXP_EXTRACT(pseudo_user_key, r'u(\d+)') AS INT64) AS user_num
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_users`
), calendar AS (
  SELECT day_offset
  FROM UNNEST(GENERATE_ARRAY(0, 89)) AS day_offset
)
SELECT
  u.pseudo_user_key,
  DATE_SUB(DATE '2026-05-01', INTERVAL c.day_offset DAY) AS event_date,
  CASE
    WHEN MOD(u.user_num + c.day_offset, 13) = 0 THEN 'purchase'
    WHEN MOD(u.user_num + c.day_offset, 7) = 0 THEN 'add_to_cart'
    WHEN MOD(u.user_num + c.day_offset, 5) = 0 THEN 'product_view'
    ELSE 'session_start'
  END AS event_name,
  1 + MOD(u.user_num + c.day_offset, 4) AS session_count,
  CAST(5 + MOD(u.user_num * 3 + c.day_offset, 55) AS FLOAT64) AS active_minutes
FROM users u
CROSS JOIN calendar c
WHERE MOD(u.user_num + c.day_offset, CASE WHEN MOD(u.user_num, 5) = 2 THEN 9 ELSE 4 END) = 0;

-- ============================================================
-- 3. Synthetic source table: orders
-- ============================================================

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_orders` AS
WITH users AS (
  SELECT
    pseudo_user_key,
    CAST(REGEXP_EXTRACT(pseudo_user_key, r'u(\d+)') AS INT64) AS user_num
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_users`
), calendar AS (
  SELECT day_offset
  FROM UNNEST(GENERATE_ARRAY(0, 89)) AS day_offset
)
SELECT
  u.pseudo_user_key,
  DATE_SUB(DATE '2026-05-01', INTERVAL c.day_offset DAY) AS order_date,
  CAST(10 + MOD(u.user_num * 17 + c.day_offset * 11, 190) AS FLOAT64) AS order_amount
FROM users u
CROSS JOIN calendar c
WHERE MOD(u.user_num + c.day_offset, CASE WHEN MOD(u.user_num, 5) = 0 THEN 11 ELSE 23 END) = 0;

-- ============================================================
-- 4. Training feature / label table
-- Observation window: 2026-03-03 to 2026-04-01 (30 days)
-- Prediction window: 2026-04-02 to 2026-05-01 (30 days)
-- Label churned = 1 when no event appears in prediction window.
-- ============================================================

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features` AS
WITH params AS (
  SELECT DATE '2026-04-01' AS as_of_date
), observed_events AS (
  SELECT
    e.pseudo_user_key,
    SUM(e.session_count) AS sessions_30d,
    COUNTIF(e.event_name = 'purchase') AS purchases_30d,
    DATE_DIFF((SELECT as_of_date FROM params), MAX(e.event_date), DAY) AS days_since_last_visit
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_events` e
  WHERE e.event_date BETWEEN DATE_SUB((SELECT as_of_date FROM params), INTERVAL 29 DAY)
                         AND (SELECT as_of_date FROM params)
  GROUP BY e.pseudo_user_key
), observed_orders AS (
  SELECT
    o.pseudo_user_key,
    SUM(o.order_amount) AS revenue_90d
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_orders` o
  WHERE o.order_date BETWEEN DATE_SUB((SELECT as_of_date FROM params), INTERVAL 89 DAY)
                         AND (SELECT as_of_date FROM params)
  GROUP BY o.pseudo_user_key
), future_activity AS (
  SELECT DISTINCT e.pseudo_user_key
  FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_events` e
  WHERE e.event_date BETWEEN DATE_ADD((SELECT as_of_date FROM params), INTERVAL 1 DAY)
                         AND DATE_ADD((SELECT as_of_date FROM params), INTERVAL 30 DAY)
)
SELECT
  u.pseudo_user_key,
  u.segment_key,
  COALESCE(oe.sessions_30d, 0) AS sessions_30d,
  COALESCE(oe.purchases_30d, 0) AS purchases_30d,
  COALESCE(oe.days_since_last_visit, 999) AS days_since_last_visit,
  COALESCE(oo.revenue_90d, 0.0) AS revenue_90d,
  -- Synthetic label guardrail: ensure both classes exist for BQML classification demo.
  -- This is education-only synthetic logic, not a real churn definition.
  CASE
    WHEN u.segment_key = 'dormant_risk' THEN 1
    WHEN COALESCE(oe.sessions_30d, 0) <= 2 AND COALESCE(oo.revenue_90d, 0.0) = 0 THEN 1
    WHEN fa.pseudo_user_key IS NULL AND MOD(CAST(REGEXP_EXTRACT(u.pseudo_user_key, r'u(\d+)') AS INT64), 3) = 0 THEN 1
    ELSE 0
  END AS churned
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_users` u
LEFT JOIN observed_events oe USING (pseudo_user_key)
LEFT JOIN observed_orders oo USING (pseudo_user_key)
LEFT JOIN future_activity fa USING (pseudo_user_key);

-- ============================================================
-- 5. BQML model: Logistic regression churn model
-- ============================================================

CREATE OR REPLACE MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
OPTIONS(
  model_type = 'LOGISTIC_REG',
  input_label_cols = ['churned'],
  auto_class_weights = TRUE,
  data_split_method = 'AUTO_SPLIT'
) AS
SELECT
  sessions_30d,
  purchases_30d,
  days_since_last_visit,
  revenue_90d,
  churned
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`;

-- ============================================================
-- 6. Evaluation result table
-- ============================================================

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_model_evaluation` AS
SELECT *
FROM ML.EVALUATE(
  MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
);

-- ============================================================
-- 7. Segment action priority result table
-- This is intentionally segment-level, not a customer list.
-- ============================================================

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_segment_action_priority` AS
WITH predictions AS (
  SELECT
    pseudo_user_key,
    segment_key,
    predicted_churned,
    predicted_churned_probs
  FROM ML.PREDICT(
    MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`,
    (
      SELECT
        pseudo_user_key,
        segment_key,
        sessions_30d,
        purchases_30d,
        days_since_last_visit,
        revenue_90d
      FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
    )
  )
), scored AS (
  SELECT
    pseudo_user_key,
    segment_key,
    predicted_churned,
    (
      SELECT prob
      FROM UNNEST(predicted_churned_probs)
      WHERE label = 1
      LIMIT 1
    ) AS churn_probability
  FROM predictions
)
SELECT
  segment_key,
  COUNT(*) AS pseudo_user_count,
  AVG(churn_probability) AS avg_churn_probability,
  CASE
    WHEN AVG(churn_probability) >= 0.70 THEN 'high_priority_retention_message'
    WHEN AVG(churn_probability) >= 0.50 THEN 'medium_priority_activation_nudge'
    ELSE 'monitor_only'
  END AS recommended_action
FROM scored
GROUP BY segment_key
ORDER BY avg_churn_probability DESC;

-- ============================================================
-- 8. OPTIONAL appendix: Confusion matrix
-- Default execution pack excludes this block.
-- Uncomment only if SY님 separately approves optional appendix result tables.
-- Use only for 90-minute version or appendix.
-- ============================================================

-- CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_confusion_matrix` AS
-- SELECT *
-- FROM ML.CONFUSION_MATRIX(
--   MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
-- );

-- ============================================================
-- 9. OPTIONAL appendix: ROC curve
-- Default execution pack excludes this block.
-- Uncomment only if SY님 separately approves optional appendix result tables.
-- Use only for 90-minute version or appendix.
-- ============================================================

-- CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_roc_curve` AS
-- SELECT *
-- FROM ML.ROC_CURVE(
--   MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
-- );

-- ============================================================
-- 10. Verification SELECTs
-- These are safe read checks after execution.
-- ============================================================

SELECT 'users' AS table_name, COUNT(*) AS row_count
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_users`
UNION ALL
SELECT 'events', COUNT(*)
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_events`
UNION ALL
SELECT 'orders', COUNT(*)
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_orders`
UNION ALL
SELECT 'training_features', COUNT(*)
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`;

SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_model_evaluation`;

SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_segment_action_priority`
ORDER BY avg_churn_probability DESC;

-- ============================================================
-- 11. Cleanup reference only. DO NOT RUN unless SY님 explicitly approves cleanup.
-- ============================================================

-- DROP SCHEMA `bigquery-course-356601.bqml_course_internal_analyst` CASCADE;
