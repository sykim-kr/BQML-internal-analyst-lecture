# Game Regression Query Pack v0 — BQML 첫 번째 예시

- Project: `lecture-bqml-internal-analyst-202605`
- SQL file: `03-drafts/game-regression-query-pack-v0.sql`
- Source attachment: `game---6b3b8ef7-e252-4a1a-9a4b-a0cbd61cca13.csv`
- Note: replaces previous CSV because `RANK` was missing.
- Related original material: `20190121_빅쿼리ML_데모.pptx` p9~16 게임 데이터 예시
- Target BigQuery project: `bigquery-course-356601`
- Dataset: `bqml_course_internal_analyst`
- Status: draft query package, not yet executed by Chrong
- Security: L2 if executed; sample game data only

## 1. Why this comes first

이 게임 데이터 예시는 BQML을 처음 보여주기에 가장 단순하다.

- 입력 feature가 직관적이다.
  - 게임시간
  - 로그인횟수
  - 달성레벨
- 예측 target이 명확하다.
  - 예상매출액
- 모델 유형이 쉽다.
  - `LINEAR_REG`
- 강의 메시지가 간단하다.
  - “SQL로 모델을 만들고, 평가하고, 특정 사용자의 예상 매출을 예측한다.”

따라서 PPTX 앞부분에서 BQML의 기본 흐름을 보여주는 첫 번째 예시로 배치한다.

## 2. Source schema mapping

원본 CSV 컬럼은 BigQuery 강의용으로 아래처럼 변환한다.

| Source column | BigQuery column | Meaning |
|---|---|---|
| `New_C.ID.` | `user_id` | 샘플 게임 사용자 ID |
| `게임시간` | `game_time` | 게임 플레이 시간 |
| `로그인횟수` | `login_count` | 로그인 횟수 |
| `달성레벨` | `level_achieved` | 달성 레벨 |
| `예상매출액` | `purchase_amount` | 예측 대상 매출액 |
| `RANK` | `rank_value` | 매출 순위/참고 컬럼 |

모델링 메모:
- `rank_value`는 table/profile/result preview에는 포함한다.
- 하지만 `purchase_amount` 순위에서 파생된 값으로 보이므로, 매출 예측 feature에서는 제외한다.
- 강의에서는 target leakage 예시로 짧게 언급할 수 있다.

보안 메모:
- 본 실습은 첨부된 sample game dataset 기준이다.
- CSV/DOCX/이미지는 분석 대상 source material로만 취급한다.
- 직접 식별자, 실제 고객/개인 데이터, credential은 포함하지 않는다.
- BigQuery 실행이 필요하면 기존 L2 게이트를 적용한다.

## 3. Query package output

실행 시 생성될 리소스:

- `bqml_course_game_data`
- `bqml_course_game_data_profile`
- `bqml_course_game_revenue_model_v0`
- `bqml_course_game_model_evaluation`
- `bqml_course_game_user156_prediction`
- `bqml_course_game_all_predictions`

## 4. BQML flow

```text
game_data table
→ CREATE MODEL LINEAR_REG
→ ML.EVALUATE
→ ML.PREDICT for user_id=156
→ actual vs predicted purchase amount 비교
```

## 5. Teaching points

1. `CREATE MODEL`은 SQL로 모델을 만드는 단계다.
2. `ML.EVALUATE`는 모델 성능을 숫자로 확인하는 단계다.
3. `ML.PREDICT`는 새 대상 또는 holdout 대상의 예측값을 만드는 단계다.
4. 회귀 모델은 “얼마나 클 것인가?”를 예측한다.
5. 이 예시는 BQML의 문법과 흐름을 이해시키는 첫 예시이며, 이후 churn classification 예제로 확장한다.

## 6. PPTX placement

PPTX 앞부분 배치안:

1. BQML 한 줄 소개
2. BQML 기본 흐름: `CREATE MODEL → ML.EVALUATE → ML.PREDICT`
3. 첫 번째 예시: 게임 매출 예측
4. 게임 데이터 컬럼 설명
5. `LINEAR_REG` 모델 생성
6. 모델 평가 지표
7. 특정 사용자 `user_id=156` 예측
8. 실제값 vs 예측값 비교
9. 그 다음 예시로 churn classification 이동

## 7. Open execution note

이 query pack은 아직 Chrong이 BigQuery에 실행하지 않았다.
실행 시에는 기존 L2 기준을 따른다.

- 기존 리소스 확인
- dry run/비용 추정
- 실행 로그 기록
- SY님 승인 문구 확인
- BigQuery write 실행
