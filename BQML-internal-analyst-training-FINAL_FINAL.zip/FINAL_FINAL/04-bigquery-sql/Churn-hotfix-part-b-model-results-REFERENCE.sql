-- BigQuery Hotfix PART B — model/evaluation/prediction result tables
-- Execute ONLY after PART A sanity check returns both churned=0 and churned=1.
-- Target project: bigquery-course-356601
-- Security: L2, synthetic/sample data only, pseudo_user_key only.

-- Final guard check before model creation.
SELECT churned, COUNT(*) AS row_count
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
GROUP BY churned
ORDER BY churned;

CREATE OR REPLACE MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
OPTIONS(
  model_type = 'LOGISTIC_REG',
  input_label_cols = ['churned'],
  auto_class_weights = TRUE,
  data_split_method = 'AUTO_SPLIT'
) AS
SELECT
  sessions_30d,
  purchases_30d,
  days_since_last_visit,
  revenue_90d,
  churned
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`;

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_model_evaluation` AS
SELECT *
FROM ML.EVALUATE(
  MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`
);

CREATE OR REPLACE TABLE `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_segment_action_priority` AS
WITH predictions AS (
  SELECT
    pseudo_user_key,
    segment_key,
    predicted_churned,
    predicted_churned_probs
  FROM ML.PREDICT(
    MODEL `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_churn_model_v0`,
    (
      SELECT
        pseudo_user_key,
        segment_key,
        sessions_30d,
        purchases_30d,
        days_since_last_visit,
        revenue_90d
      FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`
    )
  )
), scored AS (
  SELECT
    pseudo_user_key,
    segment_key,
    predicted_churned,
    (
      SELECT prob
      FROM UNNEST(predicted_churned_probs)
      WHERE label = 1
      LIMIT 1
    ) AS churn_probability
  FROM predictions
)
SELECT
  segment_key,
  COUNT(*) AS pseudo_user_count,
  AVG(churn_probability) AS avg_churn_probability,
  CASE
    WHEN AVG(churn_probability) >= 0.70 THEN 'high_priority_retention_message'
    WHEN AVG(churn_probability) >= 0.50 THEN 'medium_priority_activation_nudge'
    ELSE 'monitor_only'
  END AS recommended_action
FROM scored
GROUP BY segment_key
ORDER BY avg_churn_probability DESC;

-- Verification SELECTs.
SELECT 'users' AS table_name, COUNT(*) AS row_count
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_users`
UNION ALL
SELECT 'events', COUNT(*)
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_events`
UNION ALL
SELECT 'orders', COUNT(*)
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_sample_orders`
UNION ALL
SELECT 'training_features', COUNT(*)
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_training_features`;

SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_model_evaluation`;

SELECT *
FROM `bigquery-course-356601.bqml_course_internal_analyst.bqml_course_segment_action_priority`
ORDER BY avg_churn_probability DESC;
