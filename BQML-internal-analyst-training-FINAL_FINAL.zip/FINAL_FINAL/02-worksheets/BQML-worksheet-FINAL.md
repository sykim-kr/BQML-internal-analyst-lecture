# BQML Internal Analyst Training v7 — 수강생 워크시트

## 사용 방법
- 각 파트는 강의 중 5–10분 단위 실습으로 사용합니다.
- 정답 하나를 맞히는 문제가 아니라, 분석 질문을 모델링 질문과 액션 후보로 바꾸는 사고 연습입니다.
- 모든 threshold/flag는 자동 조치 기준이 아니라 **검토·실험·우선순위 후보 신호**로 표현합니다.
- 민감속성, 가족상태, 소득, 직접 식별자, 예측 시점 이후 정보는 feature에서 제외합니다.

---

# Worksheet 1. 분석 질문을 ML 문제로 바꾸기

## 1-1. 우리 업무 질문 쓰기
- 업무 질문:
- 이 질문이 필요한 이유:
- 예측 결과를 사용할 의사결정:

## 1-2. ML 문제로 변환하기
| 항목 | 작성 |
|---|---|
| 예측하려는 대상 |  |
| 맞히고 싶은 결과(label) |  |
| 예측 시점 |  |
| 예측 기간(window) |  |
| 모델 유형 후보 | regression / classification / clustering / forecasting |
| 결과 사용 방식 | 검토 / 실험 / 우선순위 / 모니터링 |

## 1-3. 변수 후보 초안
| 변수 후보 | 행동/서비스 이용 신호인가? | 예측 시점에 알 수 있는가? | 제외 필요 여부 |
|---|---:|---:|---:|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

---

# Worksheet 2. CREATE MODEL SQL 읽기

아래 항목을 기준으로 BQML SQL을 읽어봅니다.

| 체크 항목 | 작성 |
|---|---|
| model_type |  |
| input_label_cols |  |
| feature 컬럼 |  |
| label 컬럼 |  |
| 제외한 컬럼 |  |
| data_split_method |  |
| holdout/evaluation 방식 |  |
| 운영 적용 시 추가로 필요한 검증 |  |

## data_split_method 생각해보기
- demo에서 `NO_SPLIT`을 쓰는 이유:
- 실제 운영에서 `AUTO_SPLIT` 또는 별도 evaluation table이 필요한 이유:
- 학습 데이터와 예측/평가 대상이 섞이면 생길 문제:

---

# Worksheet 3. Evaluation metric 해석

## 3-1. 회귀 평가 지표
| Metric | 의미 | 우리 업무에서 해석 |
|---|---|---|
| MAE | 평균 절대 오차 |  |
| MSE | 평균 제곱 오차 |  |
| R² | 설명력 | 수식: R² = 1 - (SSE / SST). 쉽게 말해 1 - (모델이 틀린 정도 / 원래 데이터가 들쭉날쭉한 정도). 예: R²=0.72라면 실제값 변동의 약 72%를 모델이 설명한다는 뜻. 단, 높다고 무조건 좋은 모델은 아니며 과적합·데이터 누수·업무상 허용 오차를 함께 본다. |

질문:
- 예측 오차가 어느 정도면 의사결정에 허용 가능한가?
- 큰 오차가 특히 위험한 업무 상황은 무엇인가?
- R²가 높아도 실제 업무에서 쓰기 어려운 경우는 무엇인가?

## 3-2. 분류 평가 지표
| Metric | 의미 | 우선적으로 봐야 하는 상황 |
|---|---|---|
| accuracy | 전체 정답률 |  |
| precision | 찍은 대상이 실제 positive일 가능성 |  |
| recall | 실제 positive를 놓치지 않는 정도 |  |
| f1_score | precision/recall 균형 |  |
| roc_auc | threshold 전반의 구분력 |  |

## 3-3. FP/FN 비용 비교
| 오류 유형 | 업무상 비용 | 줄이기 위해 우선 볼 지표 |
|---|---|---|
| FP |  |  |
| FN |  |  |

---

# Worksheet 4. Feature Table 설계

## 4-1. 변수 유형 분류
아래 변수를 분류하세요.

| 변수 | categorical | binary | ordinal | continuous | derived | target | 제외 필요 |
|---|---:|---:|---:|---:|---:|---:|---:|
| device_type |  |  |  |  |  |  |  |
| login_count_7d |  |  |  |  |  |  |  |
| total_playtime_minutes |  |  |  |  |  |  |  |
| purchase_count_30d |  |  |  |  |  |  |  |
| days_since_last_login |  |  |  |  |  |  |  |
| completed_tutorial |  |  |  |  |  |  |  |
| churned |  |  |  |  |  |  |  |

## 4-2. Churn 예측용 feature 10개 설계
| 변수명 | 변수 유형 | 계산 방식 | 표현 방식(raw/bucket/threshold/ratio) | 예측에 도움 되는 이유 | 가능한 액션 후보 | leakage 위험 |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |

## 4-3. 제외해야 할 변수 점검
| 변수 | 제외 이유 |
|---|---|
| 직접 식별자 |  |
| 민감속성 |  |
| 가족상태/소득 등 부적절 속성 |  |
| 예측 시점 이후 정보 |  |
| label과 거의 같은 정보 |  |

---

# Worksheet 5. Prediction Result → 액션 우선순위

아래 segment/prediction result를 보고 액션 후보를 설계하세요.

| Segment | 의미 | 액션 후보 | 바로 자동 실행해도 되는가? | 실험/검토 설계 |
|---|---|---|---|---|
| dormant_risk | 미접속/저활동 위험 후보 신호 |  | 아니오 |  |
| repeat_purchaser | 반복 구매 행동 신호 |  | 아니오 |  |
| high_playtime_low_purchase | 몰입은 높지만 구매 전환이 낮은 신호 |  | 아니오 |  |
| support_need_signal | 지원 접점 증가 신호 |  | 아니오 |  |
| others | 명확한 우선 신호 없음 | monitor only | 아니오 |  |

## 최종 정리
- 우리 팀에서 바로 실험해 볼 예측 질문 1개:
- 이 질문의 label:
- 사용할 수 있는 행동 기반 feature 5개:
- 제외해야 할 변수:
- 예측 결과를 연결할 액션 후보:
