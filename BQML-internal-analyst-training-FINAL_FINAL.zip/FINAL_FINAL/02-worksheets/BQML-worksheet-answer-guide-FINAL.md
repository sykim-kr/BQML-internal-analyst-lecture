# BQML Internal Analyst Training v7 — 강사용 워크시트 해설지

## 해설 운영 원칙
- 수강생 답을 하나의 정답으로 고정하지 않습니다.
- 좋은 답의 기준은 ① 예측 시점 명확성 ② label/feature 분리 ③ leakage 회피 ④ 액션 후보 연결 ⑤ 민감속성 배제입니다.
- threshold/flag를 자동 조치 기준으로 쓰는 답은 반드시 수정 피드백합니다.

---

# Worksheet 1 해설 — 분석 질문을 ML 문제로 바꾸기

## 좋은 답 예시
- 업무 질문: 최근 활동이 줄어든 사용자가 다음 30일 안에 이탈할 가능성이 높은가?
- 예측 대상: 가명 사용자 단위 또는 segment 단위
- label: 다음 30일 이탈 여부
- 예측 시점: 오늘 또는 기준일 D
- 예측 기간: D+1 ~ D+30
- 모델 유형: classification
- 결과 사용 방식: 리텐션 실험 후보 우선순위

## 피드백 포인트
- label은 미래 결과여야 합니다.
- feature는 예측 시점 이전 행동이어야 합니다.
- user_id 같은 직접 식별자는 join key로만 사용하고 feature로 넣지 않습니다.

---

# Worksheet 2 해설 — CREATE MODEL SQL 읽기

## 좋은 답 예시
- model_type: LINEAR_REG 또는 LOGISTIC_REG
- input_label_cols: purchase_amount 또는 churned
- feature 컬럼: game_time, login_count, level_achieved 등 행동 기반 변수
- 제외 컬럼: 직접 식별자, 민감속성, 예측 시점 이후 정보
- data_split_method: demo에서는 NO_SPLIT 가능, 운영에서는 AUTO_SPLIT/RANDOM/custom eval table 권장

## 설명 포인트
- `NO_SPLIT`은 강의 demo 단순화를 위한 장치입니다.
- 실제 운영에서는 훈련/평가 데이터가 분리되어야 모델 성능을 신뢰할 수 있습니다.
- SQL은 문법보다 “어떤 컬럼을 학습했고 무엇을 맞히려 하는가”를 먼저 읽게 합니다.

---

# Worksheet 3 해설 — Evaluation metric 해석

## 회귀 지표
- MAE: 평균적으로 얼마만큼 빗나갔는가. 이해하기 쉽고 업무 설명에 좋습니다.
- MSE: 큰 오차에 더 민감합니다. 큰 실패가 위험한 예측에서 중요합니다.
- R²: 수식은 `R² = 1 - (SSE / SST)`입니다. 쉽게 말하면 `1 - (모델이 틀린 정도 / 원래 데이터가 들쭉날쭉한 정도)`입니다. 예를 들어 R²=0.72라면 “실제값이 들쭉날쭉한 정도 중 약 72%를 모델이 설명했다”는 뜻입니다. 다만 R²가 높다고 무조건 좋은 모델은 아닙니다. 과적합, target leakage, 샘플 편향, 그리고 실제 업무에서 허용 가능한 오차 범위를 함께 봐야 합니다.

## 분류 지표
- accuracy: 전체 정답률. 클래스 불균형이 있으면 단독 사용 위험.
- precision: 모델이 positive라고 찍은 대상 중 실제 positive 비율. 고비용 개입에 중요.
- recall: 실제 positive 중 모델이 찾아낸 비율. 놓치면 손실이 큰 문제에 중요.
- f1_score: precision과 recall 균형.
- roc_auc: threshold 선택 전 전반적 구분력.

## FP/FN 비용 예시
| 오류 유형 | 업무상 비용 | 우선 지표 |
|---|---|---|
| FP | 실제 위험하지 않은 고객에게 캠페인/CS 비용 사용 | precision |
| FN | 실제 위험 고객을 놓쳐 이탈/매출 손실 발생 | recall |

---

# Worksheet 4 해설 — Feature Table 설계

## 변수 유형 예시
| 변수 | 권장 분류 |
|---|---|
| device_type | categorical |
| login_count_7d | continuous / count |
| total_playtime_minutes | continuous |
| purchase_count_30d | continuous / count |
| days_since_last_login | continuous, threshold 파생 가능 |
| completed_tutorial | binary |
| churned | target |

## 좋은 feature 예시
| 변수명 | 표현 방식 | 액션 후보 | leakage 주의 |
|---|---|---|---|
| days_since_last_login | raw numeric + is_inactive_14d threshold | 재방문 유도 실험 후보 | 기준일 이후 접속정보 금지 |
| login_count_7d | raw numeric | 활동 저하 감지 | 예측 기간 내 로그인 포함 금지 |
| avg_playtime_per_login | ratio | 몰입도 기반 메시지 후보 | 분모 0 처리 필요 |
| purchase_count_30d | raw/bucket | 반복 구매/멤버십 후보 | 예측 기간 구매 포함 금지 |
| completed_tutorial | binary | 온보딩 개선 후보 | tutorial 완료 시점 확인 |

## 제외해야 할 변수 예시
- 직접 식별자: email, phone, real customer id
- 민감속성: age, gender, income, family status 등
- leakage: 예측 기간 이후 구매 여부, 이탈 확정 후 생성된 CS 티켓, label과 동일한 파생값

---

# Worksheet 5 해설 — Prediction Result를 액션 우선순위로 바꾸기

## 좋은 답 예시
| Segment | 액션 후보 | 실험/검토 설계 |
|---|---|---|
| dormant_risk | 재방문 유도 메시지 후보 | 메시지 A/B 테스트, 7일 재방문율 측정 |
| repeat_purchaser | 멤버십/번들 오퍼 후보 | 오퍼군 vs holdout 비교 |
| high_playtime_low_purchase | 구매 전환 안내/혜택 후보 | 전환 메시지 실험, 구매 전환율 측정 |
| support_need_signal | 도움말/CS 우선 검토 후보 | 지원 콘텐츠 노출 실험, 문의 감소 확인 |
| others | monitor only | 별도 자동 액션 없음 |

## 피드백 포인트
- “자동 발송”, “차단”, “제외”라고 쓰면 수정합니다.
- 좋은 표현: “실험 후보”, “우선순위 검토”, “추가 확인 대상”, “holdout 포함 검증”.
- segment는 사람을 낙인찍는 분류가 아니라 행동 신호 기반의 운영 후보군입니다.
