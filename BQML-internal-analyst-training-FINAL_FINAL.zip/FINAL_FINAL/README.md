# BQML Internal Analyst Training — FINAL_FINAL Package

Created: 2026-05-20
Status: Final working package for lecture delivery / review

이 폴더는 흩어져 있던 BQML 내부 분석가 강의 최종 산출물을 한 곳에 모은 패키지입니다.

## 가장 먼저 열 파일

1. PPT 최종본
   - `01-ppt/BQML-internal-analyst-training-deck-FINAL.pptx`

2. 수강생 워크시트
   - `02-worksheets/BQML-worksheet-FINAL.md`
   - `02-worksheets/BQML-worksheet-FINAL.html`

3. 강사용 자료
   - `03-instructor/BQML-lecture-script-FINAL.md`
   - `03-instructor/BQML-facilitator-guide-FINAL.md`
   - `03-instructor/BQML-facilitator-guide-FINAL.html`

4. BigQuery 실습 운영
   - `05-runbook/BQML-bigquery-demo-runbook-FINAL.md`
   - `04-bigquery-sql/Game-regression-query-pack-FINAL.sql`
   - `04-bigquery-sql/Churn-classification-create-evaluate-predict-FINAL.sql`

## 폴더 구조

```text
FINAL_FINAL/
  01-ppt/              # 최종 PPT
  02-worksheets/       # 수강생 워크시트 + 정답 가이드
  03-instructor/       # 강의 스크립트 + 강사용 진행 가이드
  04-bigquery-sql/     # BigQuery 실습 SQL
  05-runbook/          # BigQuery demo runbook
  06-qa/               # 참고용 QA/진단 기록
```

## 기준 버전

- PPT 기준: `bqml-internal-analyst-training-deck-v11-final-final.pptx`
- v11 반영 내용:
  - SY님 v8 수정본 기반
  - v9 디자인 polish + End Of Document 슬라이드
  - v10 R² 설명 보강
  - v11 R² 수식 `R² = 1 - (SSE / SST)` 및 중학생도 이해 가능한 해석 추가

## 주의

- `REFERENCE`가 붙은 SQL/QA 파일은 강의 운영 참고용입니다.
- BigQuery write 작업은 자동 실행하지 않습니다. 추가 CREATE/REPLACE 실행은 SY님 승인 후 진행합니다.
- PPT 텍스트는 PowerPoint에서 직접 수정 가능한 상태를 기준으로 관리합니다.
